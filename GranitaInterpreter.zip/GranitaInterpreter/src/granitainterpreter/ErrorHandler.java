/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package granitainterpreter;

import granita.Semantic.Types.ErrorType;
import granita.Semantic.Types.Type;
import java.util.ArrayList;

/**
 *
 * @author Néstor A. Bermúdez <nestor.bermudez@unitec.edu>
 */
public class ErrorHandler {

    private static ArrayList<String> errors;

    public static Type handle(String msg) {
        if (errors == null) {
            errors = new ArrayList<String>();
        }
        errors.add(msg);
        return new ErrorType();
    }

    public static void printErrors() {
        if (errors != null) {
            System.err.println(errors.size() + " errors found: ");
            for (String string : errors) {
                System.err.println("\t" + string);
            }
        }
    }
}

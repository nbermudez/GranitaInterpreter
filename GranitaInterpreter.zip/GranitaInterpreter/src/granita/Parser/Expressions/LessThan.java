/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package granita.Parser.Expressions;

import granita.Semantic.Types.BoolType;
import granita.Semantic.Types.IntType;
import granita.Semantic.Types.Type;
import granitainterpreter.GranitaException;

/**
 *
 * @author Néstor A. Bermúdez <nestor.bermudez@unitec.edu>
 */
public class LessThan extends BinaryExpression {

    public LessThan(Expression left, Expression right, int line) {
        super(left, right, line);
    }

    @Override
    public String stringRepresentation() {
        return "(" + left.stringRepresentation() + " < " + right.stringRepresentation() + ")";
    }

    @Override
    public Type validateSemantics() throws GranitaException {
        Type LHS = left.validateSemantics();
        if (LHS == null) {
            throw new GranitaException("undefined variable " + left.stringRepresentation()
                    + ": line " + line);
        }
        Type RHS = right.validateSemantics();
        if (RHS == null) {
            throw new GranitaException("undefined variable " + right.stringRepresentation()
                    + ": line " + line);
        }

        if (LHS instanceof IntType && RHS instanceof IntType) {
            return new BoolType();
        } else {
            throw new GranitaException("Operator < cannot be applied to "
                    + LHS.stringRepresentation() + " and " + RHS.stringRepresentation()
                    + ": line " + line);
        }
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package granita.Parser.Statements;

import granita.Parser.Expressions.Expression;
import granita.Parser.LeftValues.LeftValue;
import granita.Semantic.Types.Type;
import granitainterpreter.ErrorHandler;
import granitainterpreter.GranitaException;

/**
 *
 * @author Néstor A. Bermúdez <nestor.bermudez@unitec.edu>
 */
public class AssignStatement extends Statement {

    LeftValue left;
    Expression value;

    public AssignStatement(int line) {
        super(line);
    }

    public AssignStatement(LeftValue left, Expression value, int line) {
        super(line);
        this.left = left;
        this.value = value;
    }

    public LeftValue getLeft() {
        return left;
    }

    public void setLeft(LeftValue left) {
        this.left = left;
    }

    public Expression getValue() {
        return value;
    }

    public void setValue(Expression value) {
        this.value = value;
    }

    @Override
    public String stringRepresentation() {
        return left.stringRepresentation() + " = " + value.stringRepresentation();
    }

    @Override
    public void validateSemantics() throws GranitaException {
        Type LHS = left.validateSemantics();
        Type RHS = value.validateSemantics();

        if (!LHS.equivalent(RHS)) {
            ErrorHandler.handle("cannot assign " + RHS.stringRepresentation() + " to "
                    + LHS.stringRepresentation() + " variable: line " + value.getLine());
        }
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package granita.Parser.Statements;

import granita.Parser.LeftValues.LeftValue;
import granitainterpreter.GranitaException;
import java.util.ArrayList;

/**
 *
 * @author Néstor A. Bermúdez <nestor.bermudez@unitec.edu>
 */
public class ReadStatement extends Statement {
    
    ArrayList<LeftValue> leftValues;

    public ReadStatement(int line) {
        super(line);
        leftValues = new ArrayList<LeftValue>();
    }

    public ReadStatement(ArrayList<LeftValue> leftValues, int line) {
        super(line);
        this.leftValues = leftValues;
    }

    @Override
    public String stringRepresentation() {
        String read = "read ";
        for (int i = 0; i< leftValues.size() - 1 ; i++){
            read += leftValues.get(i).stringRepresentation() + ",";
        }
        read += leftValues.get(leftValues.size() - 1).stringRepresentation();
        return read;
    }

    public ArrayList<LeftValue> getLeftValues() {
        return leftValues;
    }

    public void setLeftValues(ArrayList<LeftValue> leftValues) {
        this.leftValues = leftValues;
    }

    @Override
    public void validateSemantics() throws GranitaException {
        for (LeftValue lv : leftValues){
            lv.validateSemantics();
        }
    }
    
}

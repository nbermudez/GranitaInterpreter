/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package granita.Parser.FieldItems;

import granitainterpreter.GranitaException;


/**
 *
 * @author Néstor A. Bermúdez <nestor.bermudez@unitec.edu>
 */
public class SimpleField extends Field {

    public SimpleField(String fieldName, int line) {
        super(fieldName, line);
        this.fieldName = fieldName;
    }

    @Override
    public String toString() {
        return fieldName;
    }

    @Override
    public void validateSemantics() throws GranitaException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}

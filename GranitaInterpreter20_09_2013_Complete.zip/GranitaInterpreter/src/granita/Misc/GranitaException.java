/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package granita.Misc;

/**
 *
 * @author Néstor A. Bermúdez <nestor.bermudez@unitec.edu>
 */
public class GranitaException extends Exception {

    public GranitaException(String message) {
        super(message);
    }
}
